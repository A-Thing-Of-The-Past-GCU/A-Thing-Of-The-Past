// Copyright GCU 2026. All rights reserved.


#include "Interaction/Interactable.h"

AInteractable::AInteractable()
{
	InteractionTriggerVolume = CreateDefaultSubobject<UCapsuleComponent>("Trigger Volume", false);
	InteractionTriggerVolume->SetupAttachment(RootComponent);
	
	InteractionTriggerVolume->SetCapsuleHalfHeight(50.0f);
	InteractionTriggerVolume->SetCapsuleRadius(25.0f);
	
	InteractionTriggerVolume->ShapeColor = FColor::Green;
	InteractionTriggerVolume->SetLineThickness(1.0f);
	
	InteractionTriggerVolume->SetCollisionProfileName(FName("Interactable"));
	
	PromptLocation = CreateDefaultSubobject<USceneComponent>("Prompt Location");
	PromptLocation->SetupAttachment(InteractionTriggerVolume);
}

void AInteractable::BeginPlay()
{
	Super::BeginPlay();
	
}

bool AInteractable::CanInteract_Implementation(AActor* Player)
{
	return InteractionsEnabled;
}

bool AInteractable::AttemptInteract_Implementation(AActor* Player)
{
	if (!IInteractableInterface::Execute_CanInteract(this, Player))
	{
		return false;
	}
	
	IInteractableInterface::Execute_OnInteraction(this, Player);
	return true;
}

void AInteractable::OnInteraction_Implementation(AActor* Player)
{
	UE_LOG(LogTemp, Log, TEXT("Interaction started with player (%s)"), *Player->GetName());
	
	if (DisableInteractionsAfterInteraction)
	{
		InteractionsEnabled = false;
	}
	
	if (DestroyAfterInteraction)
	{
		Destroy();
	}
}
